class Environment:

    def __init__(self):
        self.cars = []

    def add_car(self, car):
        self.cars.append(car)